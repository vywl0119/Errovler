from django.apps import AppConfig


class MakeboardConfig(AppConfig):
    name = 'MakeBoard'
